﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLDuLieuNoiBo.GiaoVu
{
    public partial class fKQHocPhan_GVU : Form
    {
        public fKQHocPhan_GVU()
        {
            InitializeComponent();
        }

        private void fKQHocPhan_GVU_Load(object sender, EventArgs e)
        {
            // Tham khảo GiangVien.fPhanCong
        }

        private void dgvDSKQHP_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
